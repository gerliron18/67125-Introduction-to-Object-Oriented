Ex6 Tester.
version 1.1

Created by Evyatar (script) and Barak (Tests).

As always, feel free to improve the tester and to share it. 

Installation:
1. Unzip everything to ex6/src (Tester_ex6_oop, README, tester_files) (same level as oop folder).
2. Open  Tester_ex6_oop with intelliJ.
3. Import junit.
4. Run the tests.


We have 3 tests:

1. runType2ErrorTests - check all cases 2 supposed to be printed. 
	a. This test is not auto test!! you have to check the results yourself (easy).

2. runAllTests - main test. 
	a. Test's all Sjava files in the folder 'tester_files/Tests'.
	b. You can add as match Sjava Files as you want (to any folder or new folder).
	c. All results are being written to the file 'tester_files/user_output.txt'. use it!
	d. It takes about 2 minutes.
	
3. runSpecificTests_optional
	a. Can be used to test specific Sjava files.
	b. Easier to debug.
	c. To use - place Sjava files under 'tester_files/Tests/specificTests'.
	d. You can copy to the folder any Sjava file, or add new ones.
	e. Also manual.
	
	
enjoy!	
	